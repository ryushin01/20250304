const Footer=()=>{
    return(
        <div className="footer-wrapper">
            <p>All rights reserved by Resto app</p>
        </div>
    )
}

export default Footer