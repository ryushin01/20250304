import MainPage from '@/containers/MainPage/MainPage';

const Home = () => {
  return <MainPage />;
};

export default Home;
