import Category from '@/containers/Category/Category';

// 카테고리 페이지 라우터
const CategoryRouter = () => {
  return (
    <div>
      <Category />
    </div>
  );
};

export default CategoryRouter;
