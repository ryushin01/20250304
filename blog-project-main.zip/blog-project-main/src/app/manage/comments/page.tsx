import React from 'react';

import ManageComments from '@/containers/ManageComments/ManageComments';

const ManageCommentsRouter = () => {
  return (
    <div>
      <ManageComments />
    </div>
  );
};

export default ManageCommentsRouter;
