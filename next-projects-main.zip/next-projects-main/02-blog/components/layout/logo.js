import classes from "./logo.module.css";

function Logo() {
  return <div className={classes.logo}>Dagny Taggart</div>;
}

export default Logo;
