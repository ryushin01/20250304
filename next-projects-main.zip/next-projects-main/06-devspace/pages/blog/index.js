import BlogPage, { getStaticProps } from "./page/[page_index]";

export default BlogPage;
export { getStaticProps };
