import Messages from "@/components/Messages";

const MessagesPage = () => {
  return <Messages />;
};
export default MessagesPage;
