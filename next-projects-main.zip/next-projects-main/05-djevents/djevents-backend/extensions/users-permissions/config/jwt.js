module.exports = {
  jwtSecret: process.env.JWT_SECRET || '581aa296-c3cc-4263-988d-abd0e4eb10d7'
};