module.exports = ({ env }) => ({
  url: env("MY_RAILWAY_URL"),
});
