export interface AnalyticsItem {
  name: string;
  uv: number;
  pv: number;
  amt: number;
}
