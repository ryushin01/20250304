function ListPage() {
  return (
    <div>
      <h1>The List Page</h1>
    </div>
  );
}

export default ListPage;
