const TeamPage = () => {
  return (
    <div>
      <h1>Our Team</h1>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Veritatis
        deleniti consectetur libero sunt consequuntur repellendus error amet
        accusamus ex itaque eligendi non necessitatibus sit quo corporis ullam
        sed, natus iste.
      </p>
    </div>
  );
};

export default TeamPage;
