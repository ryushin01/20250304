export const metadata = {
  title: "About Dagny Media",
};

const AboutPage = () => {
  return (
    <div>
      <h1>About Dagny Media</h1>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores
        doloremque voluptas est minus, alias corrupti expedita nisi odit quae
        quasi temporibus, ipsum recusandae quis earum tempore tempora velit
        aperiam vero quo error ad architecto! Aliquid accusantium quas mollitia
        aperiam id corporis amet, placeat cumque, officia praesentium modi
        voluptates quibusdam hic.
      </p>
    </div>
  );
};

export default AboutPage;
