export default function IssuesPage() {
  return <p className="message">Please select an issue</p>;
}
