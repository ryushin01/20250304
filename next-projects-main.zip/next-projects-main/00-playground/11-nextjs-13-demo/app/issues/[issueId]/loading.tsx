export default function IssueLoading() {
  return <p className="message">Loading issue data...</p>;
}
