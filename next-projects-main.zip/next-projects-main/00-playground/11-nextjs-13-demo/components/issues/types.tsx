export default interface Issue {
  id: number;
  title: string;
  summary: string;
  description: string;
}
