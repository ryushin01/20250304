# List of resumes using resume-nextjs

> The list will continue to be added.
> Welcome your pull request to add your resume URL.

## Sample

- https://uyu423.github.io/resume-nextjs

## Developer

- https://resume.yowu.dev : Node.js Back-end Developer
- https://daeheekim93.github.io/resume : Java Spring Developer
- https://devjoshua.me/ : Java Back-end Developer
